package sptech.servico;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PokemonServiceTest {

    @Test
    void validarForcaGolpe() {
        
    }
}