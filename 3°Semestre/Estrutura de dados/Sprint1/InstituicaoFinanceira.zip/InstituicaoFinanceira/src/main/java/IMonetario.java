public interface IMonetario {
    public Double calcularJuros();
}
