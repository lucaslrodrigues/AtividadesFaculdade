## Prototipo de alculadora financeira para sprint1
Ela busca calcular o valor montante de uma produção com base em valores inseridos pelo usuário levando em conta uma perda de 15% da produção.
