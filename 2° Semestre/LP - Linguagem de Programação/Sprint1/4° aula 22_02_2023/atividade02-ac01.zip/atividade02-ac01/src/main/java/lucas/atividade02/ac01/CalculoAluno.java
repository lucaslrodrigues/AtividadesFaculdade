/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lucas.atividade02.ac01;

/**
 *
 * @author aluno
 */
public class CalculoAluno {
    Double calcularMedia(Double nota1, Double nota2){
        Double media = (nota1 * 0.4) + (nota2 * 0.6);
        return media;
    }
}
